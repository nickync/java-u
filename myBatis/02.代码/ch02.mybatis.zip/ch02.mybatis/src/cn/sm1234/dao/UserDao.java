package cn.sm1234.dao;

import java.util.List;

import cn.sm1234.domain.User;

public interface UserDao {

	public List<User> queryUserOrder();
}
