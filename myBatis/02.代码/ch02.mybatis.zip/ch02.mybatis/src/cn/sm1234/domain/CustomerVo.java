package cn.sm1234.domain;
/**
 * CustomerVo包装JavaBean类型
 * @author lenovo
 */
public class CustomerVo {
	private Customer customer;
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	
}
